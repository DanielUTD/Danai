// MovieList.js (modal + ดูหนังเต็มเรื่อง)
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function MovieList() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const navigate = useNavigate();

  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    fetch("http://localhost/movix-project/backend/get_movies.php")
      .then((res) => {
        if (!res.ok) throw new Error("Network response was not ok");
        return res.json();
      })
      .then((data) => {
        setMovies(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching movies:", err);
        setError("ไม่สามารถโหลดข้อมูลได้");
        setLoading(false);
      });
  }, []);

  if (loading) return <p style={{ textAlign: "center", marginTop: 40, color: "#fff" }}>กำลังโหลดข้อมูล...</p>;
  if (error) return <p style={{ color: "red", textAlign: "center", marginTop: 40 }}>{error}</p>;

  return (
    <div style={{ backgroundColor: "#121212", minHeight: "100vh", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif", padding: "0 20px" }}>
      {/* Header */}
      <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 40, paddingBottom: 10, borderBottom: "2px solid #f04e30" }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <h1 style={{ fontWeight: "900", fontSize: "3rem", color: "#f04e30", fontFamily: "'Poppins', sans-serif", letterSpacing: "4px", margin: 0 }}>Movix</h1>
          <span style={{ marginLeft: 15, fontSize: "1.5rem", color: "#bbb" }}>รายการหนัง/ซีรีส์</span>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
          {user ? (
            <>
              <span style={{ fontSize: "1rem", color: "#fff" }}>👤 {user.Username}</span>
              <button
                onClick={() => {
                  localStorage.removeItem("user");
                  navigate("/login");
                }}
                style={{ padding: "6px 12px", backgroundColor: "#f04e30", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer" }}
              >
                ออกจากระบบ
              </button>
            </>
          ) : (
            <button
              onClick={() => navigate("/login")}
              style={{ padding: "6px 12px", backgroundColor: "#007BFF", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer" }}
            >
              เข้าสู่ระบบ
            </button>
          )}
        </div>
      </header>

      {/* Movie Grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 20 }}>
        {movies.map((movie) => (
          <div
            key={movie.MovieID}
            style={{
              position: "relative",
              borderRadius: 12,
              overflow: "hidden",
              cursor: "pointer",
              backgroundColor: "#1f1f1f",
              boxShadow: "0 8px 20px rgba(0,0,0,0.6)",
              transition: "transform 0.3s ease, box-shadow 0.3s ease",
            }}
            onClick={() => setSelectedMovie(movie)}
          >
            <div style={{ position: "relative", paddingTop: "56.25%", overflow: "hidden" }}>
              <img
                src={movie.Img_Poster}
                alt={movie.Name}
                style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
              />
              <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "50%", background: "linear-gradient(to top, rgba(0,0,0,0.85), transparent)" }} />
            </div>
            <div style={{ padding: 12, color: "#fff", textAlign: "center" }}>
              <h3 style={{ margin: "0 0 6px", fontSize: "1rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{movie.Name}</h3>
              <p style={{ margin: 0, fontSize: "0.85rem", color: "#bbb" }}><strong>Subtitle:</strong> {movie.Subtitle || "-"}</p>
              <p style={{ margin: 0, fontSize: "0.85rem", color: "#bbb" }}><strong>Voiceover:</strong> {movie.Voiceover || "-"}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Movie Detail Modal */}
      {selectedMovie && (
        <div
          onClick={() => setSelectedMovie(null)}
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            background: "rgba(0,0,0,0.85)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 100,
            padding: 20,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: "#111",
              borderRadius: 12,
              maxWidth: 900,
              width: "100%",
              padding: 20,
              color: "#fff",
              maxHeight: "90vh",
              overflowY: "auto",
            }}
          >
            <h2 style={{ marginTop: 0 }}>{selectedMovie.Name}</h2>

            <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
              <div style={{ flex: "1 1 300px", maxWidth: 300, borderRadius: 12, overflow: "hidden" }}>
                <img src={selectedMovie.Img_Poster} alt={selectedMovie.Name} style={{ width: "100%", height: 450, objectFit: "cover" }} />
              </div>
              {selectedMovie.Vdo_Trailer && (
                <div style={{ flex: "2 1 500px", borderRadius: 12, overflow: "hidden" }}>
                  <iframe
                    width="100%"
                    height="450"
                    src={selectedMovie.Vdo_Trailer}
                    title={`ตัวอย่าง: ${selectedMovie.MovieID}`}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              )}
            </div>

            <p style={{ whiteSpace: "pre-wrap", lineHeight: 1.6, fontSize: "1.1rem", color: "#ccc", marginTop: 20 }}>
              {selectedMovie.Details || "ไม่มีรายละเอียด"}
            </p>
            <p style={{ fontSize: "1rem", color: "#bbb" }}>
              <strong>Subtitle:</strong> {selectedMovie.Subtitle || "-"} | <strong>Voiceover:</strong> {selectedMovie.Voiceover || "-"}<br/>
              <strong>Episode:</strong> {selectedMovie.Episode || "-"} | <strong>Price:</strong> {selectedMovie.Price || "-"} บาท
            </p>

            <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
              <button
                onClick={() => setSelectedMovie(null)}
                style={{
                  padding: "10px 20px",
                  backgroundColor: "#555",
                  border: "none",
                  borderRadius: 6,
                  cursor: "pointer",
                  color: "#fff",
                }}
              >
                ปิด
              </button>
              <button
                onClick={() => navigate(`/movieplayer/${selectedMovie.MovieID}`)}
                style={{
                  padding: "10px 20px",
                  backgroundColor: "#f04e30",
                  border: "none",
                  borderRadius: 6,
                  cursor: "pointer",
                  color: "#fff",
                }}
              >
                ▶ ดูหนังเต็มเรื่อง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MovieList;
