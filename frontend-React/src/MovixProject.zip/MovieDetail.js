// MovieDetail.js
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

function MovieDetail() {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const res = await fetch("http://localhost/movix-project/backend/get_movies.php");
        if (!res.ok) throw new Error("Network response was not ok");
        const data = await res.json();
        const found = data.find((m) => m.MovieID.toString() === id);
        if (!found) setError("ไม่พบข้อมูลหนังเรื่องนี้");
        else setMovie(found);
      } catch (err) {
        console.error(err);
        setError("ไม่สามารถโหลดข้อมูลได้");
      } finally {
        setLoading(false);
      }
    };
    fetchMovie();
  }, [id]);

  if (loading)
    return <p style={{ textAlign: "center", marginTop: 40, color: "#fff" }}>กำลังโหลดข้อมูล...</p>;

  return (
    <div style={{ backgroundColor: "#000", minHeight: "100vh", padding: "30px 20px", color: "#fff", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      {/* ปุ่มกลับและดูหนังเต็มเรื่อง */}
      <div style={{ marginBottom: 30, display: "flex", gap: 10 }}>
        <button
          onClick={() => navigate("/Movielist")}
          style={{
            padding: "10px 20px",
            backgroundColor: "#333",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            cursor: "pointer",
            transition: "0.2s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#007BFF")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#333")}
        >
          ← กลับไปหน้ารายการ
        </button>
        <button
          onClick={() => navigate(`/movieplayer/${id}`)}
          style={{
            padding: "10px 20px",
            backgroundColor: "#f04e30",
            color: "#fff",
            border: "none",
            borderRadius: 6,
            cursor: "pointer",
            transition: "0.2s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#ff6748")}
          onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#f04e30")}
        >
          ▶ ดูหนังเต็มเรื่อง
        </button>
      </div>

      {error ? (
        <p style={{ textAlign: "center", color: "red", marginTop: 40 }}>{error}</p>
      ) : (
        <>
          <h1 style={{ fontWeight: "700", fontSize: "2.2rem", marginBottom: 20 }}>{movie.Name}</h1>

          {/* Layout 2 คอลัมน์: โปสเตอร์ + วิดีโอตัวอย่าง */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 20 }}>
            <div style={{ flex: "1 1 300px", maxWidth: "300px", borderRadius: 12, overflow: "hidden", boxShadow: "0 12px 30px rgba(0,0,0,0.6)" }}>
              <img
                src={movie.Img_Poster}
                alt={`โปสเตอร์หนัง ${movie.Name}`}
                style={{ width: "100%", height: "450px", objectFit: "cover" }}
              />
            </div>

            {movie.Vdo_Trailer && (
              <div style={{ flex: "2 1 500px", borderRadius: 12, overflow: "hidden", boxShadow: "0 12px 30px rgba(0,0,0,0.6)" }}>
                <iframe
                  width="100%"
                  height="450"
                  src={movie.Vdo_Trailer}
                  title={`ตัวอย่าง: ${movie.MovieID}`}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>
            )}
          </div>

          {/* รายละเอียดหนัง */}
          <p style={{ whiteSpace: "pre-wrap", lineHeight: 1.6, fontSize: "1.1rem", color: "#ccc", marginTop: 30 }}>
            {movie.Details}
          </p>

          <div style={{ marginTop: 20, fontSize: "1rem", color: "#bbb" }}>
            <p>
              <strong>Subtitle:</strong> {movie.Subtitle || "-"} | <strong>Voiceover:</strong> {movie.Voiceover || "-"}
            </p>
            <p>
              <strong>Episode:</strong> {movie.Episode || "-"} | <strong>Price:</strong> {movie.Price || "-"} บาท
            </p>
          </div>
        </>
      )}
    </div>
  );
}

export default MovieDetail;
