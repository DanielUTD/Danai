import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import MovieList from "./MovieList";
import MovieDetail from "./MovieDetail";
import Login from "./Login";
import Register from "./register";
import MoviePlayer from "./MoviePlayer";
import AdminLogin from "./adminlogin";
import AdminDashboard from "./admindashboard";
import MemberList from "./memberlist";
import Category from "./category";
import Home from "./home";
import AdminMovies from "./AdminMovies";

// เช็คว่ามี user login หรือยัง
const isLoggedIn = () => {
  return !!localStorage.getItem("user");
};

// เช็คว่า admin login หรือยัง
const isAdminLoggedIn = () => {
  return !!localStorage.getItem("admin");
};

// Route สำหรับ user
function PrivateRoute({ children }) {
  return isLoggedIn() ? children : <Navigate to="/login" replace />;
}

// Route สำหรับ admin
function AdminPrivateRoute({ children }) {
  return isAdminLoggedIn() ? children : <Navigate to="/adminlogin" replace />;
}

function App() {
  return (
    <Router>
      <Routes>
        {/* หน้าแรก */}
        <Route path="/" element={<Home />} />

        {/* User routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/movielist"
          element={
            <PrivateRoute>
              <MovieList />
            </PrivateRoute>
          }
        />
        <Route
          path="/movie/:id"
          element={
            <PrivateRoute>
              <MovieDetail />
            </PrivateRoute>
          }
        />
        <Route
          path="/movieplayer/:id"
          element={
            <PrivateRoute>
              <MoviePlayer />
            </PrivateRoute>
          }
        />

        {/* Admin routes */}
        <Route path="/adminlogin" element={<AdminLogin />} />
        <Route
          path="/admindashboard"
          element={
            <AdminPrivateRoute>
              <AdminDashboard />
            </AdminPrivateRoute>
          }
        />
        <Route
          path="/memberlist"
          element={
            <AdminPrivateRoute>
              <MemberList />
            </AdminPrivateRoute>
          }
        />
        <Route
          path="/category"
          element={
            <AdminPrivateRoute>
              <Category />
            </AdminPrivateRoute>
          }
        />
        <Route
          path="/AdminMovies"
          element={
            <AdminPrivateRoute>
              <AdminMovies />
            </AdminPrivateRoute>
          }
        />

        {/* ถ้า path ไม่ตรง → redirect กลับหน้าแรก */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
