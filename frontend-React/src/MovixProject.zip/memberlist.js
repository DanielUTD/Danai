// MemberList.js
import React, { useEffect, useState } from "react";

function MemberList() {
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("http://localhost/movix-project/backend/Member.php") // ปรับ URL ตามจริง
      .then((res) => {
        if (!res.ok) throw new Error("Network response was not ok");
        return res.json();
      })
      .then((data) => {
        setMembers(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setError("ไม่สามารถโหลดรายการสมาชิกได้");
        setLoading(false);
      });
  }, []);

  if (loading) return <p style={{ textAlign: "center", marginTop: 40 }}>กำลังโหลดข้อมูลสมาชิก...</p>;
  if (error) return <p style={{ textAlign: "center", marginTop: 40, color: "red" }}>{error}</p>;

  return (
    <div style={{ maxWidth: 900, margin: "50px auto", padding: "0 20px", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      <h1 style={{ textAlign: "center", marginBottom: 30 }}>รายการสมาชิก</h1>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#007BFF", color: "#fff" }}>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Email</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Username</th>
            <th style={{ padding: "10px", border: "1px solid #ddd" }}>Category</th>
          </tr>
        </thead>
        <tbody>
          {members.map((member, index) => (
            <tr key={index} style={{ textAlign: "center", borderBottom: "1px solid #ddd" }}>
              <td style={{ padding: "10px" }}>{member.MemberEmail}</td>
              <td style={{ padding: "10px" }}>{member.Username}</td>
              <td style={{ padding: "10px" }}>{member.MemberCategory}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default MemberList;
