// Home.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Home() {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("http://localhost/movix-project/backend/get_movies.php")
      .then((res) => {
        if (!res.ok) throw new Error("Network response was not ok");
        return res.json();
      })
      .then((data) => {
        setMovies(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching movies:", err);
        setError("ไม่สามารถโหลดข้อมูลได้");
        setLoading(false);
      });
  }, []);

  return (
    <div style={{ minHeight: "100vh", background: "#121212", fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }}>
      {/* Header */}
      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 50,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 24px",
          background: "#1f1f1f",
          boxShadow: "0 4px 12px rgba(0,0,0,0.6)",
        }}
      >
        <h1 style={{ margin: 0, fontSize: 30, color: "#f04e30", letterSpacing: 4, fontWeight: 900 }}>Movix</h1>

        {/* ปุ่ม Login */}
        <button
          onClick={() => navigate("/login")}
          style={{
            padding: "8px 16px",
            borderRadius: 8,
            border: "1px solid #444",
            background: "#333",
            color: "#fff",
            cursor: "pointer",
            fontWeight: 600,
            transition: "0.2s",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "#f04e30")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "#333")}
        >
          🔐 Login
        </button>
      </header>

      <main style={{ maxWidth: 1280, margin: "40px auto", padding: "0 20px" }}>
        <section style={{ marginBottom: 30 }}>
          <h2 style={{ fontSize: 24, color: "#fff", marginBottom: 6 }}>รายการหนัง/ซีรีส์</h2>
        </section>

        {loading ? (
          <p style={{ textAlign: "center", marginTop: 50, fontSize: 16, color: "#fff" }}>กำลังโหลดข้อมูล...</p>
        ) : error ? (
          <p style={{ textAlign: "center", marginTop: 50, fontSize: 16, color: "red" }}>{error}</p>
        ) : movies.length === 0 ? (
          <p style={{ textAlign: "center", marginTop: 50, fontSize: 16, color: "#fff" }}>ไม่พบข้อมูลหนัง/ซีรีส์</p>
        ) : (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
              gap: 20,
            }}
          >
            {movies.map((movie) => (
              <article
                key={movie.MovieID}
                onClick={() => setSelectedMovie(movie)}
                style={{
                  position: "relative",
                  borderRadius: 12,
                  overflow: "hidden",
                  cursor: "pointer",
                  background: "#222",
                  boxShadow: "0 8px 20px rgba(0,0,0,0.5)",
                  transition: "transform 0.3s ease, box-shadow 0.3s ease",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = "scale(1.05)";
                  e.currentTarget.style.boxShadow = "0 18px 40px rgba(0,0,0,0.7)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = "scale(1)";
                  e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.5)";
                }}
              >
                <div style={{ position: "relative", paddingTop: "56.25%", overflow: "hidden" }}>
                  <img
                    src={movie.Img_Poster}
                    alt={movie.Name}
                    style={{
                      position: "absolute",
                      inset: 0,
                      width: "100%",
                      height: "100%",
                      objectFit: "cover",
                      transition: "transform 0.3s ease",
                    }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      height: "50%",
                      background: "linear-gradient(to top, rgba(0,0,0,0.85), transparent)",
                    }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      top: "50%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      fontSize: 40,
                      color: "#f04e30",
                      opacity: 0.8,
                    }}
                  >
                    ▶️
                  </div>
                </div>

                <div style={{ padding: 14, color: "#fff" }}>
                  <h3 style={{ margin: 0, fontSize: 16, lineHeight: 1.3, height: "2.6em", overflow: "hidden" }}>{movie.Name}</h3>
                  <p style={{ margin: "6px 0 0", fontSize: 13, color: "#bbb" }}>
                    <strong>Subtitle:</strong> {movie.Subtitle || "-"}<br/>
                    <strong>Voiceover:</strong> {movie.Voiceover || "-"}
                  </p>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Modal */}
        {selectedMovie && (
          <div
            onClick={() => setSelectedMovie(null)}
            style={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100vw",
              height: "100vh",
              background: "rgba(0,0,0,0.85)",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              zIndex: 100,
              padding: 20,
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                background: "#111",
                borderRadius: 12,
                maxWidth: 800,
                width: "100%",
                padding: 20,
                color: "#fff",
                maxHeight: "90vh",
                overflowY: "auto",
              }}
            >
              <h2 style={{ marginTop: 0 }}>{selectedMovie.Name}</h2>
              <img
                src={selectedMovie.Img_Poster}
                alt={selectedMovie.Name}
                style={{ width: "100%", borderRadius: 8, marginBottom: 15 }}
              />
              <p>{selectedMovie.Details || "ไม่มีรายละเอียด"}</p>
              <p>
                <strong>Subtitle:</strong> {selectedMovie.Subtitle || "-"} |{" "}
                <strong>Voiceover:</strong> {selectedMovie.Voiceover || "-"}
              </p>
              <p>
                <strong>Episode:</strong> {selectedMovie.Episode || "-"} |{" "}
                <strong>Price:</strong> {selectedMovie.Price || "-"} บาท
              </p>
              {selectedMovie.Vdo_Trailer && (
                <div style={{ marginTop: 20, borderRadius: 12, overflow: "hidden" }}>
                  <iframe
                    width="100%"
                    height="400"
                    src={selectedMovie.Vdo_Trailer}
                    title={`ตัวอย่าง: ${selectedMovie.MovieID}`}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>
              )}
              <button
                onClick={() => setSelectedMovie(null)}
                style={{
                  marginTop: 20,
                  padding: "10px 20px",
                  backgroundColor: "#f04e30",
                  border: "none",
                  borderRadius: 6,
                  cursor: "pointer",
                  color: "#fff",
                }}
              >
                ปิด
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default Home;
