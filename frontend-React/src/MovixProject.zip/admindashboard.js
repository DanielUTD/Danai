// AdminDashboard.js
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

function AdminDashboard() {
  const navigate = useNavigate();

  // อ่านข้อมูล admin จาก localStorage
  const adminData = localStorage.getItem("admin");
  let admin = null;
  try {
    admin = adminData ? JSON.parse(adminData) : null;
  } catch {
    admin = null;
  }

  // ถ้าไม่มี admin → redirect ไปหน้า login
  useEffect(() => {
    if (!admin) {
      navigate("/adminlogin");
    }
  }, [admin, navigate]);

  if (!admin) return null; // กัน render เนื้อหาก่อน redirect

  const buttonStyle = {
    padding: "20px 30px",
    fontSize: "1.1rem",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    margin: "10px 0",
    width: "250px",
    color: "#fff",
    boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
    transition: "all 0.2s ease-in-out",
  };

  const handleLogout = () => {
    localStorage.removeItem("admin");
    navigate("/adminlogin");
  };

  return (
    <div
      style={{
        maxWidth: 800,
        margin: "50px auto",
        padding: "0 20px",
        textAlign: "center",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      {/* Header */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: 40,
          borderBottom: "2px solid #f04e30",
          paddingBottom: 10,
        }}
      >
        <h1 style={{ fontSize: "2rem", color: "#222", margin: 0 }}>
          Admin Dashboard
        </h1>
        <div style={{ textAlign: "right" }}>
          <p style={{ margin: "0 0 5px", fontWeight: "bold", color: "#333" }}>
            👋 สวัสดี, {admin.AdminUser}
          </p>
          <button
            onClick={handleLogout}
            style={{
              padding: "6px 12px",
              backgroundColor: "#dc3545",
              color: "#fff",
              border: "none",
              borderRadius: 6,
              cursor: "pointer",
              fontSize: "0.9rem",
            }}
          >
            ออกจากระบบ
          </button>
        </div>
      </header>

      {/* Menu buttons */}
      <div>
        <button
          style={{ ...buttonStyle, backgroundColor: "#007BFF" }}
          onClick={() => navigate("/AdminMovies")}
        >
          เพิ่ม/แก้ไขหนัง
        </button>
      </div>

      <div>
        <button
          style={{ ...buttonStyle, backgroundColor: "#28A745" }}
          onClick={() => navigate("/category")}
        >
          จัดการประเภทหนัง
        </button>
      </div>

      <div>
        <button
          style={{ ...buttonStyle, backgroundColor: "#FFC107", color: "#222" }}
          onClick={() => navigate("/memberlist")}
        >
          ดูรายการสมาชิก
        </button>
      </div>
    </div>
  );
}

export default AdminDashboard;
