// AdminMovies.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function AdminMovies() {
  const navigate = useNavigate();
  const [admin, setAdmin] = useState(null);
  const [movies, setMovies] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [formType, setFormType] = useState("add");
  const [currentMovie, setCurrentMovie] = useState({
    MovieID: "",
    Name: "",
    Img_Poster: "",
    Details: "",
    Subtitle: "",
    Voiceover: "",
    Group: "",
    Vdo_Trailer: "",
    Episode: 1,
    Price: 0,
    Viewer: 0,
    CategoryID: 1,
  });
  const [message, setMessage] = useState("");

  // ตรวจสอบ admin login
  useEffect(() => {
    const savedAdmin = JSON.parse(localStorage.getItem("admin"));
    if (!savedAdmin) {
      alert("กรุณาเข้าสู่ระบบ Admin");
      navigate("/adminlogin");
    } else {
      setAdmin(savedAdmin);
      fetchMovies();
      fetchCategories();
    }
  }, [navigate]);

  const fetchMovies = () => {
    fetch("http://localhost/movix-project/backend/get_movies.php")
      .then(res => res.json())
      .then(data => { setMovies(data); setLoading(false); })
      .catch(err => { console.error(err); setLoading(false); });
  };

  const fetchCategories = () => {
    fetch("http://localhost/movix-project/backend/Category.php")
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error(err));
  };

  const generateMovieID = () => {
    if (!movies.length) return "MV001";
    const lastID = movies[movies.length - 1].MovieID;
    const num = parseInt(lastID.slice(2)) + 1;
    return "MV" + String(num).padStart(3, "0");
  };

  const getYouTubeEmbed = (url) => {
    try {
      if (!url) return null;
      const urlObj = new URL(url);
      let id = "";
      if (urlObj.hostname.includes("youtu.be")) {
        id = urlObj.pathname.slice(1);
      } else {
        id = urlObj.searchParams.get("v");
      }
      if (!id) return null;
      return `https://www.youtube.com/embed/${id}`;
    } catch {
      return null;
    }
  };

  const openAddForm = () => {
    setFormType("add");
    setCurrentMovie({
      MovieID: generateMovieID(),
      Name: "",
      Img_Poster: "",
      Details: "",
      Subtitle: "",
      Voiceover: "",
      Group: "",
      Vdo_Trailer: "",
      Episode: 1,
      Price: 0,
      Viewer: 0,
      CategoryID: categories[0]?.CategoryID || 1,
    });
    setFormOpen(true);
    setMessage("");
  };

  const openEditForm = (movie) => {
    setFormType("edit");
    setCurrentMovie({ ...movie });
    setFormOpen(true);
    setMessage("");
  };

  const handleDelete = (id) => {
    if (!window.confirm("คุณแน่ใจว่าจะลบหนังเรื่องนี้?")) return;
    fetch(`http://localhost/movix-project/backend/DeleteMovie.php?id=${id}`, { method: "DELETE" })
      .then(res => res.json())
      .then(data => { alert(data.message); fetchMovies(); })
      .catch(err => console.error(err));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!admin) return;

    if (!currentMovie.Name || !currentMovie.CategoryID || !admin.AdminEmail) {
      setMessage("กรุณากรอกข้อมูลให้ครบ");
      return;
    }

    const url = formType === "add"
      ? "http://localhost/movix-project/backend/AddMovie.php"
      : "http://localhost/movix-project/backend/EditMovie.php";

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...currentMovie, EmailAdmin: admin.AdminEmail })
      });
      const data = await res.json();
      setMessage(data.message);

      if (data.success) {
        setFormOpen(false);
        if (formType === "add" && data.MovieID) {
          setMovies(prev => [...prev, { ...currentMovie, MovieID: data.MovieID }]);
        } else {
          fetchMovies();
        }
      }
    } catch (err) {
      console.error(err);
      setMessage("เกิดข้อผิดพลาด");
    }
  };

  if (loading) return <p style={{ textAlign: "center", marginTop: 40 }}>กำลังโหลดข้อมูล...</p>;

  return (
    <div style={{ maxWidth: 1100, margin: "50px auto", padding: "0 20px" }}>
      <h1 style={{ textAlign: "center", marginBottom: 30 }}>จัดการหนัง/ซีรีส์/การ์ตูน</h1>
      <button
        onClick={openAddForm}
        style={{ marginBottom: 20, padding: "10px 20px", backgroundColor: "#28A745", color: "#fff", border: "none", borderRadius: 6 }}
      >
        ➕ เพิ่มหนังใหม่
      </button>

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
  <thead>
    <tr style={{ backgroundColor: "#007BFF", color: "#fff" }}>
      <th style={{ padding: 10, border: "1px solid #ddd" }}>ลำดับ</th> {/* เลขลำดับ */}
      <th style={{ padding: 10, border: "1px solid #ddd" }}>ID</th>
      <th style={{ padding: 10, border: "1px solid #ddd" }}>ชื่อหนัง</th>
      <th style={{ padding: 10, border: "1px solid #ddd" }}>Category</th>
      <th style={{ padding: 10, border: "1px solid #ddd" }}>Poster/Preview</th>
      <th style={{ padding: 10, border: "1px solid #ddd" }}>Action</th>
    </tr>
  </thead>
  <tbody>
    {movies.map((movie, index) => (
      <tr key={movie.MovieID} style={{ textAlign: "center", borderBottom: "1px solid #ddd" }}>
        <td style={{ padding: 10 }}>{index + 1}</td> {/* เลขลำดับแถว */}
        <td style={{ padding: 10 }}>{movie.MovieID}</td>
        <td style={{ padding: 10 }}>{movie.Name}</td>
        <td style={{ padding: 10 }}>{categories.find(c => c.CategoryID === movie.CategoryID)?.CategoryName || movie.CategoryID}</td>
        <td style={{ padding: 10 }}>
          {movie.Img_Poster && <img src={movie.Img_Poster} alt="poster" style={{ width: 60 }} />}<br />
          {movie.Vdo_Trailer && getYouTubeEmbed(movie.Vdo_Trailer) && (
            <iframe
              width="200"
              height="120"
              src={getYouTubeEmbed(movie.Vdo_Trailer)}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              style={{ marginTop: 5 }}
            />
          )}
        </td>
        <td style={{ padding: 10 }}>
          <button onClick={() => openEditForm(movie)} style={{ marginRight: 10, padding: "5px 10px", backgroundColor: "#FFC107", border: "none", borderRadius: 4 }}>✏️ แก้ไข</button>
          <button onClick={() => handleDelete(movie.MovieID)} style={{ padding: "5px 10px", backgroundColor: "#DC3545", border: "none", borderRadius: 4, color: "#fff" }}>🗑 ลบ</button>
        </td>
      </tr>
    ))}
  </tbody>
</table>


      {formOpen && (
        <div style={{ position: "fixed", top: 0, left: 0, width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0.5)", display: "flex", justifyContent: "center", alignItems: "center" }}>
          <div style={{ backgroundColor: "#fff", padding: 20, borderRadius: 10, width: 500 }}>
            <h2>{formType === "add" ? "เพิ่มหนังใหม่" : "แก้ไขหนัง"}</h2>
            <form onSubmit={handleSubmit}>
              <input type="text" placeholder="ชื่อหนัง" value={currentMovie.Name} onChange={e => setCurrentMovie({ ...currentMovie, Name: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="text" placeholder="URL Poster" value={currentMovie.Img_Poster} onChange={e => setCurrentMovie({ ...currentMovie, Img_Poster: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              {currentMovie.Img_Poster && <img src={currentMovie.Img_Poster} alt="poster" style={{ width: 100, marginBottom: 10 }} />}
              <textarea placeholder="รายละเอียด" value={currentMovie.Details} onChange={e => setCurrentMovie({ ...currentMovie, Details: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="text" placeholder="Subtitle" value={currentMovie.Subtitle} onChange={e => setCurrentMovie({ ...currentMovie, Subtitle: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="text" placeholder="Voiceover" value={currentMovie.Voiceover} onChange={e => setCurrentMovie({ ...currentMovie, Voiceover: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="text" placeholder="กลุ่ม" value={currentMovie.Group} onChange={e => setCurrentMovie({ ...currentMovie, Group: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="text" placeholder="URL Video Trailer" value={currentMovie.Vdo_Trailer} onChange={e => setCurrentMovie({ ...currentMovie, Vdo_Trailer: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="number" placeholder="Episode" value={currentMovie.Episode} onChange={e => setCurrentMovie({ ...currentMovie, Episode: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <input type="number" placeholder="Price" value={currentMovie.Price} onChange={e => setCurrentMovie({ ...currentMovie, Price: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }} />
              <select value={currentMovie.CategoryID} onChange={e => setCurrentMovie({ ...currentMovie, CategoryID: e.target.value })} style={{ width: "100%", padding: 8, marginBottom: 10 }}>
                {categories.map(c => <option key={c.CategoryID} value={c.CategoryID}>{c.CategoryName}</option>)}
              </select>
              <button type="submit" style={{ padding: "10px 20px", backgroundColor: "#28A745", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer" }}>บันทึก</button>
              <button type="button" onClick={() => setFormOpen(false)} style={{ padding: "10px 20px", marginLeft: 10, backgroundColor: "#6c757d", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer" }}>ยกเลิก</button>
            </form>
            {message && <p style={{ marginTop: 10, color: message.includes("เรียบร้อย") || message.includes("สำเร็จ") ? "green" : "red" }}>{message}</p>}
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminMovies;
